# Guia do Sistema — Let's Go

> Manual do utilizador final. Existe também em Word, pronto a imprimir/entregar:
> [`Guia_Sistema_Lets_Go.docx`](Guia_Sistema_Lets_Go.docx).

## 1. O essencial

### Os dois ficheiros

| | 📗 Operacional | 🔒 Financeiro |
|---|---|---|
| **Quem usa** | Toda a equipa | Só a gestora |
| **Para quê** | Reservas, clientes, voos, hotéis, passageiros, pagamentos recebidos | Comissões, margens, custos fixos, lucro, caixa |

O Financeiro lê sozinho o Operacional — não é preciso copiar nada.

> **A regra mais importante:** o Financeiro **nunca** é partilhado com os atendentes. É essa a
> única forma de as comissões e margens ficarem privadas.

### A regra de ouro das cores

| Cor | Significa |
|---|---|
| ⚪ Branca | Escreva à vontade |
| 🔵 Azul-clara | Não toque — é calculada |

### O menu «Let's Go»

| Opção | Para quê |
|---|---|
| 💾 Guardar reserva | Criar reserva (e cliente, se novo) |
| 👤 Atualizar cliente | Corrigir dados de um cliente |
| ➕ Adicionar serviço | Juntar voo/hotel/transporte |
| ➕ Adicionar passageiro | Juntar quem viaja além do titular |
| 💳 Registar pagamento | Lançar um valor recebido |
| ✅ Aprovar reserva / definir venda | *(gestora)* fixar o preço |
| 📄 Gerar PDF do comprovativo | Comprovativo para o cliente |

Tudo começa na aba **`Formulário`**.

## 2. O dia a dia da equipa

### Criar uma reserva
1. Abrir `Formulário`.
2. Escolher o cliente existente **ou** preencher os dados do cliente novo.
3. Preencher pacote, datas, nº de passageiros e tipo de pagamento.
4. `Let's Go ▸ 💾 Guardar reserva`.

A reserva nasce em **«Aguarda aprovação» e sem preço** — é de propósito. O titular entra
automaticamente nos passageiros.

### Adicionar voos, hotéis e transportes
Cada serviço é uma linha. Uma viagem de três cidades pode ter três voos e dois hotéis.
1. `Formulário` ▸ secção **Adicionar serviço**.
2. Escolher a reserva e o tipo (Aéreo/Hotel/Transporte).
3. Voos: trecho, localizador, escalas, duração, embarque e desembarque.
   Hotéis: nome, check-in, check-out.
4. Indicar o custo ▸ `Let's Go ▸ ➕ Adicionar serviço`.

O custo total da reserva soma-se sozinho.

### Adicionar passageiros
1. Secção **Adicionar passageiro** ▸ escolher a reserva.
2. Nome, documento, validade, nacionalidade, nascimento e **aeroporto de partida** dessa pessoa.
3. `Let's Go ▸ ➕ Adicionar passageiro`.

O sistema calcula a **idade à data da viagem** (não a de hoje) e avisa se o documento expira:
🔴 expira antes do regresso · 🟡 validade curta · 🟢 OK.

### Registar um pagamento
1. Secção **Registar pagamento** ▸ reserva, data, valor, método.
2. `Let's Go ▸ 💳 Registar pagamento`.

Fica o histórico todo. O sistema recusa valores acima do que falta pagar.

### Consultar / check-in
Aba `Ficha de Reserva` ▸ procurar por **nome** (ou telemóvel, email, ID). Mostra titular,
manifesto de passageiros, todos os voos/hotéis e a situação dos pagamentos.

### Comprovativo
`Ficha de Reserva` ▸ escolher a reserva ▸ `Let's Go ▸ 📄 Gerar PDF do comprovativo`.
O PDF vai para a pasta **`Let's Go - Comprovativos`** no Drive.

## 3. O dia a dia da gestão

### Aprovar e definir o preço
1. Ver as pendentes: indicador **«Por aprovar»** no `Início` ou aba `Gestão de Clientes`.
2. `Formulário` ▸ **Aprovar reserva / definir venda** ▸ escolher a reserva.
3. Conferir o custo total e escrever o valor de venda (já com margem).
4. `Let's Go ▸ ✅ Aprovar reserva / definir venda`.

Se a venda for inferior ao custo, o sistema pergunta se tem a certeza.

### Acompanhar clientes
Aba `Gestão de Clientes`: ❌ canceladas (com motivo) · 📝 em orçamento · ⏳ por aprovar.
Cada linha tem contactado?, próxima ação e data de follow-up.

### Ver o negócio
Aba `Dashboard` (Financeiro): faturação, margem, **lucro previsto vs. lucro de caixa**,
a receber, saldo de caixa, ticket médio, receita do último mês e variação.

> **Faturação não é lucro.** Lucro = margem − comissões − custos fixos − gastos.

### Lançar despesas
| Aba | Quando |
|---|---|
| `Gastos Adicionais` | Publicidade, material, deslocações, equipamento |
| `Saídas de Caixa` | Sempre que sai dinheiro da conta (é o que torna o caixa real) |
| `Custos Fixos` | Renda, salários, software, contabilidade |

## 4. O que nunca fazer

1. Partilhar o **Financeiro** com atendentes.
2. Escrever por cima de colunas **azuis**.
3. Apagar linhas de `Registos` para corrigir — lançar antes um **estorno** (valor negativo).
4. Exportar para Excel e reimportar — **estraga as fórmulas**. Duplicar só com
   `Ficheiro ▸ Criar uma cópia`.
5. Apagar as abas `Configurações`, `Serviços`, `Passageiros` ou `Registos`.

## 5. Problemas comuns

| Sintoma | Solução |
|---|---|
| Não aparece o menu «Let's Go» | Atualizar (F5); se persistir, o script não está instalado |
| «Não foi possível guardar» | Ler a mensagem — falta um campo ou uma data está errada |
| «Pagamento superior ao valor pendente» | Confirmar o valor; talvez já tenha sido registado |
| Reserva sem preço | Normal até a gestora aprovar |
| Financeiro sem dados novos | Verificar o `IMPORTRANGE` e clicar em «Permitir acesso» |
| `#REF!` numa aba de consulta | Alguém escreveu por baixo de uma lista automática — apagar |
| PDF no sítio errado | Confirmar a partilha da pasta `Let's Go - Comprovativos` |

**E se alguém se enganar?** A aba `Histórico` regista tudo (quem, quando, célula, valor antes
e depois) e o Google Sheets tem `Ficheiro ▸ Histórico de versões`.
